/*
 *	Copyright 2019 Steve White
 *
 *	Licensed under the Apache License, Version 2.0 (the "License"); you may not
 *	use this file except in compliance with the License. You may obtain a copy
 *	of the License at:
 *
 *		http://www.apache.org/licenses/LICENSE-2.0
 *
 *	Unless required by applicable law or agreed to in writing, software
 *	distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 *	WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 *	License for the specific language governing permissions and limitations
 *	under the License.
 *
 *
 */
metadata 
{
	definition(name: "HubConnect Omnipurpose Sensor", namespace: "shackrat", author: "Steve White", importUrl: "https://raw.githubusercontent.com/HubitatCommunity/HubConnect/master/SmartThings/DeviceTypes/HubConnect-Omnipurpose-Sensor.groovy")
	{
		capability "Motion Sensor"
		capability "Temperature Measurement"
		capability "Relative Humidity Measurement"
		capability "Illuminance Measurement"
		capability "Ultraviolet Index"
		capability "Power Source"
		capability "Tamper Alert"
		capability "Battery"
		capability "Refresh"

		attribute "version", "string"
		
		command "sync"
	}

	tiles (scale: 2) 
	{
		multiAttributeTile(name: "motion", type: "generic", width: 6, height: 4)
		{
			tileAttribute("device.motion", key: "PRIMARY_CONTROL")
			{
				attributeState "active", label: 'motion', icon: "st.motion.motion.active", backgroundColor: "#00A0DC"
				attributeState "inactive", label: 'no motion', icon: "st.motion.motion.inactive", backgroundColor: "#cccccc"
			}
		}
		valueTile("temperature", "device.temperature", width: 2, height: 2)
		{
			state("temperature", label: '${currentValue}°', unit: "F",
					backgroundColors: [
							[value: 31, color: "#153591"],
							[value: 44, color: "#1e9cbb"],
							[value: 59, color: "#90d2a7"],
							[value: 74, color: "#44b621"],
							[value: 84, color: "#f1d801"],
							[value: 95, color: "#d04e00"],
							[value: 96, color: "#bc2323"]
					]
			)
		}
		valueTile("illuminance", "device.illuminance", decoration: "flat", inactiveLabel: false, width: 2, height: 2)
		{
			state "illuminance", label: '${currentValue}% illuminance', unit: ""
		}
		valueTile("battery", "device.battery", decoration: "flat", inactiveLabel: false, width: 2, height: 2)
		{
			state "battery", label: '${currentValue}% battery', unit: ""
		}
		standardTile("motion","device.motion", inactiveLabel: false, width: 2, height: 2) 
		{
			state "inactive",label:'no motion',icon:"st.motion.motion.inactive",backgroundColor:"#ffffff"
			state "active",label:'motion',icon:"st.motion.motion.active",backgroundColor:"#00a0dc"
		}
		
		valueTile("humidity","device.humidity", inactiveLabel: false, width: 2, height: 2) 
		{
			state "humidity",label:'${currentValue} % RH'
		}	
		standardTile("refresh", "device.power", inactiveLabel: false, decoration: "flat", width: 2, height: 2)
		{
			state "default", label: '', action: "refresh.refresh", icon: "st.secondary.refresh"
		}
		standardTile("sync", "sync", inactiveLabel: false, decoration: "flat", width: 2, height: 2)
		{
			state "default", label: 'Sync', action: "sync", icon: "st.Bath.bath19"
		}
		valueTile("version", "version", inactiveLabel: false, decoration: "flat", width: 2, height: 2)
		{
			state "default", label: '${currentValue}'
		}
		valueTile("ultravioletIndex","device.ultravioletIndex", inactiveLabel: false, width: 2, height: 2) 
		{
			state "ultravioletIndex",label:'${currentValue} UV INDEX',unit:""
		}
		standardTile("acceleration", "device.acceleration", inactiveLabel: false, width: 2, height: 2) 
		{
			state("inactive", label:'clear', icon:"st.motion.acceleration.inactive", backgroundColor:"#ffffff")
			state("active", label:'tamper', icon:"st.motion.acceleration.active", backgroundColor:"#f39c12")
		}
		valueTile("battery", "device.battery", inactiveLabel: false, width: 2, height: 2) 
		{
			state "battery", label:'${currentValue}% battery', unit:""
		}
		           
		main(["motion", "temperature"])
		details(["motion", "sync", "temperature", "humidity", "illuminance", "ultravioletIndex", 
			"refresh", "battery", "version"])
	}
}


/*
	installed
    
	Doesn't do much other than call initialize().
*/
def installed()
{
	initialize()
}


/*
	updated
    
	Doesn't do much other than call initialize().
*/
def updated()
{
	initialize()
}


/*
	initialize
    
	Doesn't do much other than call refresh().
*/
def initialize()
{
	refresh()
}


/*
	parse
    
	In a virtual world this should never be called.
*/
def parse(String description)
{
	log.trace "Msg: Description is $description"
}


/*
	refresh
    
	Refreshes the device by requesting an update from the client hub.
*/
def refresh()
{
	// The server will update status
	parent.sendDeviceEvent(device.deviceNetworkId, "refresh")
}


/*
	sync
    
	Synchronizes the device details with the parent.
*/
def sync()
{
	// The server will respond with updated status and details
	parent.syncDevice(device.deviceNetworkId, "omnipurpose")
	sendEvent([name: "version", value: "v${driverVersion.major}.${driverVersion.minor}.${driverVersion.build}"])
}
def getDriverVersion() {[platform: "SmartThings", major: 1, minor: 4, build: 0]}