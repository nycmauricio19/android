package com.adjust.test;

/**
 * Created by nonelse on 09.03.17.
 */

public interface IOnExitListener {
    void onExit();
}
