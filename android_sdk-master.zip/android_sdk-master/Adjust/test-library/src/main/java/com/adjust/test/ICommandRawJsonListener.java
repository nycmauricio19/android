package com.adjust.test;

/**
 * Created by nonelse on 10.03.17.
 */

public interface ICommandRawJsonListener {
    void executeCommand(String json);
}
