package com.adjust.test.ws;

/**
 * com.adjust.test.ws
 * Created by 2beens on 08.02.19.
 */
public enum SignalType {
    INFO,
    INIT_TEST_SESSION,
    END_WAIT,
    CANCEL_CURRENT_TEST,
    UNKNOWN
}
