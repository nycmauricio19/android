package com.adjust.test;

import java.util.List;
import java.util.Map;

/**
 * Created by nonelse on 09.03.17.
 */

public class TestCommand {
    public String className;
    public String functionName;
    public Map<String, List<String>> params;
}
