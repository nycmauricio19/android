package com.adjust.sdk;

/**
 * Created by pfms on 11/08/2016.
 */
public class StateEndSession {
    boolean pausing = true;
    boolean updateActivityState = true;
    boolean eventBufferingEnabled = false;
    boolean checkOnPause = false;
    boolean foregroundAlreadySuspended = false;
    boolean backgroundTimerStarts = false;
}
