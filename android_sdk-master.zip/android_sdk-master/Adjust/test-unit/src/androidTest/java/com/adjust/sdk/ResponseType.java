package com.adjust.sdk;

/**
 * Created by pfms on 28/01/15.
 */
public enum ResponseType {
    NULL, CLIENT_PROTOCOL_EXCEPTION, INTERNAL_SERVER_ERROR, WRONG_JSON, EMPTY_JSON, MESSAGE;
}
