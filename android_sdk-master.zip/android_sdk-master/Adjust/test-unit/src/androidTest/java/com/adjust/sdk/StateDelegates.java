package com.adjust.sdk;

/**
 * Created by pfms on 15/08/2016.
 */
public class StateDelegates {
    boolean attributionDelegatePresent;
    boolean eventSuccessDelegatePresent;
    boolean eventFailureDelegatePresent;
    boolean sessionSuccessDelegatePresent;
    boolean sessionFailureDelegatePresent;
}
