package com.adjust.sdk;

/**
 * Created by pfms on 11/08/2016.
 */
public class StateEvent {
    String bufferedSuffix = null;
    Integer backgroundTimerStarts = null;
    String activityStateSuffix = null;
    String orderId = null;
    boolean duplicatedOrderId = false;
    boolean disabled = false;
}
