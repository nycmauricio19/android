package com.adjust.sdk;

/**
 * Created by pfms on 29/01/16.
 */
public interface OnDeviceIdsRead {
    void onGoogleAdIdRead(String googleAdId);
}
