package com.adjust.sdk;

public interface OnAttributionChangedListener {
    void onAttributionChanged(AdjustAttribution attribution);
}
