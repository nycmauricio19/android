package com.adjust.sdk;

/**
 * Created by pfms on 29/07/2016.
 */
public interface IRunActivityHandler {
    void run(ActivityHandler activityHandler);
}
