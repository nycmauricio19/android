package com.adjust.sdk;

import android.net.Uri;

/**
 * Created by pfms on 09/02/16.
 */
public class AttributionResponseData extends ResponseData {
    public Uri deeplink;
}
