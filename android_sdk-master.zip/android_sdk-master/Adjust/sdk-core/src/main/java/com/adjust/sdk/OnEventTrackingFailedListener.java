package com.adjust.sdk;

/**
 * Created by pfms on 04/01/16.
 */
public interface OnEventTrackingFailedListener {
    void onFinishedEventTrackingFailed(AdjustEventFailure eventFailureResponseData);
}
