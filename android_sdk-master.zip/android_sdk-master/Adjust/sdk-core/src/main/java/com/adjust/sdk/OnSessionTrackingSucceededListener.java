package com.adjust.sdk;

/**
 * Created by pfms on 16/02/16.
 */
public interface OnSessionTrackingSucceededListener {
    void onFinishedSessionTrackingSucceeded(AdjustSessionSuccess sessionSuccessResponseData);
}
