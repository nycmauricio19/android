package com.adjust.sdk;

/**
 * Created by pfms on 04/01/16.
 */
public interface OnEventTrackingSucceededListener {
    void onFinishedEventTrackingSucceeded(AdjustEventSuccess eventSuccessResponseData);
}
